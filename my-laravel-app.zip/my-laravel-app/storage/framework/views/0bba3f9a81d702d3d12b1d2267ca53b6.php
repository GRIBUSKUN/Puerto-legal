<?php
    $currentRoute = Route::currentRouteName();
?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <?php echo $__env->make('const-elements.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body class="font-sans antialiased dark:bg-black dark:text-white/50">
        <!-- header section end -->
        <div class="header_section">
            <?php echo $__env->make('const-elements.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- header section end -->

       <!-- Body section start -->
        <?php switch($currentRoute):

        case ( 'inicio' ): ?>
            <?php echo $__env->make('pages.inicio', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>

       <?php case ( 'nosotros' ): ?>
            <?php echo $__env->make('pages.nosotros', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>

        <?php case ( 'blog' ): ?>
            <?php echo $__env->make('pages.blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>

        <?php case ( 'contacto' ): ?>
            <?php echo $__env->make('pages.contacto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php break; ?>

        <?php endswitch; ?>
       <!-- Body section end -->

        <!-- footer section start -->
        <?php echo $__env->make('const-elements.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- javascript -->
    </body>
</html>
<?php /**PATH /var/www/resources/views/pages.blade.php ENDPATH**/ ?>