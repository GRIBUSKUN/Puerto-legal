<div class="title_page">
    <div class="container">
        <div class="row">
            <h1><?php echo e($title); ?></h1>
        </div>
    </div>
</div>
<?php /**PATH /var/www/resources/views/components/title.blade.php ENDPATH**/ ?>