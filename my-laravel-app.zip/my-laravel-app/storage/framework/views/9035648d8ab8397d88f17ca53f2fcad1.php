
      <!-- studies section start -->
      <div class="studies_section layout_padding">
         <div class="container">
            <div class="row">
               <div class="col-sm-12">
                  <h1 class="studies_taital">Ultimos Casos</h1>
               </div>
            </div>
            <div class="studies_section_2">
               <div class="row">
                  <div class="col-md-4">
                     <div class="hover01 column">
                        <figure><img src="images/service-img1.png"></figure>
                     </div>
                     <div class="studies_box">
                        <h3 class="introduction_text">Máster of Law, 2010</h3>
                     </div>
                     <div class="read_bt"><a href="#">Leer Más</a></div>
                  </div>
                  <div class="col-md-4">
                     <div class="hover01 column">
                        <figure><img src="images/service-img2.png"></figure>
                     </div>
                     <div class="studies_box">
                        <h3 class="introduction_text">Máster of Law, 2012</h3>
                     </div>
                     <div class="read_bt active"><a href="#">Leer Más</a></div>
                  </div>
                  <div class="col-md-4">
                     <div class="hover01 column">
                        <figure><img src="images/service-img3.png"></figure>
                     </div>
                     <div class="studies_box">
                        <h3 class="introduction_text">Máster of Law, 2014</h3>
                     </div>
                     <div class="read_bt"><a href="#">Leer Más</a></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- studies section end -->
<?php /**PATH /var/www/resources/views/components/studies.blade.php ENDPATH**/ ?>