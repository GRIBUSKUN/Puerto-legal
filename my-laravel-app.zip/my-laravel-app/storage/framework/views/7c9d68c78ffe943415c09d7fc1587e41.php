<?php echo $__env->make('components.title', ['title' => 'Nosotros'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('components.about', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /var/www/resources/views/pages/nosotros.blade.php ENDPATH**/ ?>