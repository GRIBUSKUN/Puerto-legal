
      <!-- services section start -->
      <div class="services_section">
         <div class="container">
            <div class="row">
               <div class="col-sm-12">
                  <h1 class="studies_taital">Nurestros Servicios</h1>
               </div>
            </div>
         </div>
         <div class="services_section_2">
            <div id="main_slider" class="carousel slide" data-ride="carousel">
               <div class="carousel-inner">
                  <div class="carousel-item active">
                     <div class="container">
                        <div class="row">
                           <div class="col-md-4">
                              <div class="service_box">
                                 <div class="house_icon">
                                    <img src="images/icon-1.png" class="image_1">
                                    <img src="images/icon-4.png" class="image_2">
                                 </div>
                                 <h3 class="corporate_text">Corporate Law</h3>
                                 <p class="chunks_text">chunks as necessary, making this the first true generator on the Internet. It uses a dictionary </p>
                                 <div class="readmore_button"><a href="#">Leer Más</a></div>
                              </div>
                           </div>
                           <div class="col-md-4">
                              <div class="service_box active">
                                 <div class="house_icon">
                                    <img src="images/icon-5.png" class="image_1">
                                    <img src="images/icon-5.png" class="image_2">
                                 </div>
                                 <h3 class="corporate_text">Employments Law</h3>
                                 <p class="chunks_text">chunks as necessary, making this the first true generator on the Internet. It uses a dictionary </p>
                                 <div class="readmore_button active"><a href="#">Leer Más</a></div>
                              </div>
                           </div>
                           <div class="col-md-4">
                              <div class="service_box">
                                 <div class="house_icon">
                                    <img src="images/icon-3.png" class="image_1">
                                    <img src="images/icon-6.png" class="image_2">
                                 </div>
                                 <h3 class="corporate_text">International Law</h3>
                                 <p class="chunks_text">chunks as necessary, making this the first true generator on the Internet. It uses a dictionary </p>
                                 <div class="readmore_button"><a href="#">Leer Más</a></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="carousel-item">
                     <div class="container">
                        <div class="row">
                           <div class="col-md-4">
                              <div class="service_box">
                                 <div class="house_icon">
                                    <img src="images/icon-1.png" class="image_1">
                                    <img src="images/icon-4.png" class="image_2">
                                 </div>
                                 <h3 class="corporate_text">Corporate Law</h3>
                                 <p class="chunks_text">chunks as necessary, making this the first true generator on the Internet. It uses a dictionary </p>
                                 <div class="readmore_button"><a href="#">Leer Más</a></div>
                              </div>
                           </div>
                           <div class="col-md-4">
                              <div class="service_box active">
                                 <div class="house_icon">
                                    <img src="images/icon-5.png" class="image_1">
                                    <img src="images/icon-5.png" class="image_2">
                                 </div>
                                 <h3 class="corporate_text">Employments Law</h3>
                                 <p class="chunks_text">chunks as necessary, making this the first true generator on the Internet. It uses a dictionary </p>
                                 <div class="readmore_button active"><a href="#">Leer Más</a></div>
                              </div>
                           </div>
                           <div class="col-md-4">
                              <div class="service_box">
                                 <div class="house_icon">
                                    <img src="images/icon-3.png" class="image_1">
                                    <img src="images/icon-6.png" class="image_2">
                                 </div>
                                 <h3 class="corporate_text">International Law</h3>
                                 <p class="chunks_text">chunks as necessary, making this the first true generator on the Internet. It uses a dictionary </p>
                                 <div class="readmore_button"><a href="#">Leer Más</a></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="carousel-item">
                     <div class="container">
                        <div class="row">
                           <div class="col-md-4">
                              <div class="service_box">
                                 <div class="house_icon">
                                    <img src="images/icon-1.png" class="image_1">
                                    <img src="images/icon-4.png" class="image_2">
                                 </div>
                                 <h3 class="corporate_text">Corporate Law</h3>
                                 <p class="chunks_text">chunks as necessary, making this the first true generator on the Internet. It uses a dictionary </p>
                                 <div class="readmore_button"><a href="#">Leer Más</a></div>
                              </div>
                           </div>
                           <div class="col-md-4">
                              <div class="service_box active">
                                 <div class="house_icon">
                                    <img src="images/icon-5.png" class="image_1">
                                    <img src="images/icon-5.png" class="image_2">
                                 </div>
                                 <h3 class="corporate_text">Employments Law</h3>
                                 <p class="chunks_text">chunks as necessary, making this the first true generator on the Internet. It uses a dictionary </p>
                                 <div class="readmore_button active"><a href="#">Leer Más</a></div>
                              </div>
                           </div>
                           <div class="col-md-4">
                              <div class="service_box">
                                 <div class="house_icon">
                                    <img src="images/icon-3.png" class="image_1">
                                    <img src="images/icon-6.png" class="image_2">
                                 </div>
                                 <h3 class="corporate_text">International Law</h3>
                                 <p class="chunks_text">chunks as necessary, making this the first true generator on the Internet. It uses a dictionary </p>
                                 <div class="readmore_button"><a href="#">Leer Más</a></div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <a class="carousel-control-prev" href="#main_slider" role="button" data-slide="prev">
               <i class="fa fa-arrow-left"></i>
               </a>
               <a class="carousel-control-next" href="#main_slider" role="button" data-slide="next">
               <i class="fa fa-arrow-right"></i>
               </a>
            </div>
         </div>
      </div>
      <!-- services section end -->
<?php /**PATH /var/www/resources/views/components/services.blade.php ENDPATH**/ ?>