      <!-- about section start -->
      <div class="about_section layout_padding">
         <div class="container">
            <div class="row">
               <div class="col-md-6">
                  <div class="about_img"><img src="images/about-img.png"></div>
               </div>
               <div class="col-md-6">
                  <div class="about_text_main">
                     <h1 class="about_taital">Acerca de nosotros</h1>
                     <p class="about_text">cualquier cosa vergonzosa escondida en medio del texto. Todos los generadores de Lorem Ipsum en Internet tienden a repetir fragmentos predefinidos según sea necesario, lo que lo convierte en el primer generador verdadero en Intervitnet.</p>
                     <div class="readmore_bt"><a href="#">Leer Más</a></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- about section end -->

<?php /**PATH /var/www/resources/views/components/about.blade.php ENDPATH**/ ?>