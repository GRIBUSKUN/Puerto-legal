@include('components.title', ['title' => 'Nosotros'])
@include('components.about')
