<div class="title_page">
    <div class="container">
        <div class="row">
            <h1>{{$title}}</h1>
        </div>
    </div>
</div>
