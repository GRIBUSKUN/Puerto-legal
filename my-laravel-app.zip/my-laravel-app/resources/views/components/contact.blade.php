
      <!-- contact section start -->
      <div class="contact_section layout_padding">
         <div class="container">
            <div class="row">
               <div class="col-sm-12">
                  <h1 class="contact_taital">reservar una cita</h1>
               </div>
            </div>
            <div class="contact_section_2">
               <div class="row">
                  <div class="col-md-12">
                     <div class="mail_section map_form_container">
                        <form action="">
                           <input type="text" class="mail_text" placeholder="Nombre" name="Name">
                           <input type="text" class="mail_text" placeholder="Telefono" name="Phone Number">
                           <input type="text" class="mail_text" placeholder="Correo Electronico" name="Your Email">
                           <textarea class="massage-bt" placeholder="Mensaje" rows="5" id="comment" name="Mássage"></textarea>
                           <div class="send_bt active"><a href="#">Enviar ahora</a></div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- contact section end -->
