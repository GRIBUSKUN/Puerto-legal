      <!-- box section start -->
      <div class="container">
         <div class="box_section">
            <div class="online_box">
               <div class="online_box_left">
                  <div class="online_box_main">
                     <div class="box_left">
                        <div class="right_arrow"><i class="fa fa-arrow-right"></i></div>
                     </div>
                     <div class="box_right">
                        <p class="book_text">Reservar</p>
                        <h4 class="appoinment_text">Cita</h4>
                     </div>
                  </div>
               </div>
               <div class="online_box_left active">
                  <div class="online_box_main">
                     <div class="box_left">
                        <div class="right_arrow"><i class="fa fa-arrow-right"></i></div>
                     </div>
                     <div class="box_right">
                        <p class="book_text active">Asesoría</p>
                        <h4 class="appoinment_text active">Gratuita</h4>
                     </div>
                  </div>
               </div>
               <div class="online_box_left">
                  <div class="online_box_main">
                     <div class="box_left">
                        <div class="right_arrow"><i class="fa fa-arrow-right"></i></div>
                     </div>
                     <div class="box_right">
                        <p class="book_text">Pago</p>
                        <h4 class="appoinment_text">En linea</h4>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- box section end -->

