<div class="title_page">
    <div class="container">
        <div class="row">
            <h1>{{ $title }}</h1>
            <div class="col-md-12">
                <div class="col-md-6">
                    <p>Junio 24 2024</p>
                </div>
                <div class="col-md-6">
                    <p>Escrito por Erick Becerra</p>
                </div>
            </div>
        </div>
    </div>
</div>
